import 'package:flutter/material.dart';

class TimeWatched extends StatefulWidget {
  const TimeWatched({super.key});

  @override
  State<TimeWatched> createState() => _TimeWatchedState();
}

class _TimeWatchedState extends State<TimeWatched> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
